from django.conf.urls import   url
from rest_framework.urlpatterns import format_suffix_patterns
from myapp.views import PatientViewSet,PatientDetailsCacheViewSet,PatientAllDetailsCacheViewSet

urlpatterns = [
	url(r'^patients$', PatientViewSet.as_view(), name='patients_data_api'),
	url(r'^get_patients_cache/(?P<registration_number>[\w-]+)$', PatientDetailsCacheViewSet.as_view(), name='get_patients_details_cache_api'),
	url(r'^get_patients_cache/$', PatientAllDetailsCacheViewSet.as_view(), name='get_patients_all_details_cache_api'),


]