import string
import random
from django.core.management.base import BaseCommand, CommandError
from django.conf import settings
from myapp.models import *
from datetime import date, datetime, timedelta
import time
import requests
import json
from datetime import date, datetime, timedelta
import time

def random_string_generator(size, type=None):
    if type == "char":
        chars = chars = string.ascii_uppercase + string.ascii_lowercase
    elif type == "string":
        chars = chars = string.ascii_uppercase + string.ascii_lowercase
    elif type == "number":
        chars = string.digits
    return ''.join(random.choice(chars) for _ in range(size))


loc_list={'Hyd':1,'Sec':2}
visit_date =  datetime.now().strftime("%Y-%m-%d") 

class Command(BaseCommand):

    def add_arguments(self, parser):
        parser.add_argument('count', type=int)

    def handle(self, *args, **options):
        count = options.get('count')

        service_url = "http://localhost:8002/myapp/patients" 
        i = 0
        for each_loop in range(count):
          i = i + 1  
          loc_choice = random.choice(loc_list.keys())             
          bookmark_answers_dict ={ 
                "registration_number" : i,
                "first_name": random_string_generator(4, 'char').title(),
                "visit_date" : visit_date,
                "location" : loc_choice
            }
          print json.dumps(bookmark_answers_dict)

          response = requests.post(service_url, data=json.dumps(bookmark_answers_dict),headers = {'content-type': 'application/json'})
          print response.content 

                    








