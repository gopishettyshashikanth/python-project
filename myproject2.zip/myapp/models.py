from django.db import models

# Create your models here.

class Patient(models.Model):
   
    registration_number = models.CharField(max_length=100,blank=True, null=True)
    first_name = models.CharField(max_length=250, blank=True, null=True)
    visit_date = models.DateTimeField(blank=True, null=True)
    location = models.CharField(max_length=250, blank=True, null=True)
    

    class Meta:
        verbose_name_plural = "Patient"
        verbose_name = 'Patient'
    
    def __str__(self):
        return '%s' % self.registration_number
